package lab7;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import org.jblas.DoubleMatrix;
import org.jblas.Solve;


public class Lab7 {
    public static final String gammastring = "0123456789";
    public static boolean CheckKey(String TempKey) {
        for (int l = 0; l < TempKey.length(); l++) {
            if (!(gammastring.contains(String.valueOf(TempKey.charAt(l))))) {
                System.out.println("Матрица может содержать только числа");
                return false;
            }
        }
        return true;
    }

    public static double[] multiplier(double[][] A, int[] B) {

        int aRows = A.length;
        int aColumns = A[0].length;
        int bRows = B.length;

        if (aColumns != bRows) {
            throw new IllegalArgumentException("A:Rows: " + aColumns + " Не совпадают B:Columns " + bRows + ".");
        }

        double[] C = new double[B.length];

        for (int i = 0; i < aRows; i++) { 
            for (int k = 0; k < aColumns; k++) { 
                C[i] += A[i][k] * B[k];
            }
        }

        return C;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in,"Cp1251"));
        String alb = "абвгдежзиклмнопрстуфхцчшщъьэюя";

        ArrayList<Character> alphabet = new ArrayList<>();
        for (char c : alb.toCharArray()) {
            alphabet.add(c);
        }

        Scanner in = new Scanner(System.in,"Cp1251");

        System.out.println("Введите текст: ");

        String messagetmp = in.nextLine().toLowerCase();
        char[] messagetmp2 = messagetmp.toCharArray(); 
        Map<Integer, Character> mark = new LinkedHashMap<>();  
        ArrayList<Character> messages = new ArrayList<>();   
        for (int i = 0; i < messagetmp2.length; i++) {
            if (alphabet.contains(messagetmp2[i])) {
                messages.add(messagetmp2[i]);
            } else {
                mark.put(i, messagetmp2[i]);
            }
        }

        char[] message = new char[messages.size()]; 
        for (int i = 0; i < messages.size(); i++) {
            message[i] = messages.get(i);
        }

        System.out.println("Введите размер матрицы:");
        String keytmp = reader.readLine();
        while (!CheckKey(keytmp)) {
            keytmp = reader.readLine();
        }
        int num = Integer.parseInt(keytmp);

        while (num > message.length) {
            System.out.println("Ошибка: Слишком большой размер матрицы");
            num = in.nextInt();
        }
        boolean flag = false;

        double matrix[][] = new double[num][num];

        System.out.println("Введите элементы матрицы:");
        for (int i = 0; i < num; i++) {
            for (int j = 0; j < num; j++) {
                keytmp = reader.readLine();
                while (!CheckKey(keytmp)) {
                    keytmp = reader.readLine();
                }
                matrix[i][j] = Integer.parseInt(keytmp);
            }
        }

        int alph[] = new int[message.length];

        for (int i = 0; i < message.length; i++) {
            alph[i] = alphabet.indexOf(message[i]);
        }

        int perem = alph.length;
        int step = 0;
        List<int[]> encode = new ArrayList();
        int[] messagePart = new int[0];
        while (perem >= num) {
            messagePart = Arrays.copyOfRange(alph, step, (step + num));
            step += num;
            perem -= num;
            double[] C = multiplier(matrix, messagePart);
            int[] intArray = new int[C.length];
            for (int i = 0; i < intArray.length; ++i) {
                intArray[i] = (int) Math.round(C[i]);
            }
            encode.add(intArray);
            int k = 0;
        }

        ArrayList<String> result = new ArrayList<>();
        Set<Map.Entry<Integer, Character>> set = mark.entrySet();

        int decoded[] = new int[message.length];
        int q = 0;
        for (int[] is : encode) {
            for (int i : is) {
                result.add(Integer.toString(i));
                decoded[q] = i;
                q++;
            }
        }

        double matrixTMP[][] = new double[matrix.length][matrix.length];
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix.length; j++) {
                matrixTMP[i][j] = matrix[i][j];
            }
        }

        DoubleMatrix smth = new DoubleMatrix(matrixTMP);
        DoubleMatrix inverseMatrix = Solve.pinv(smth);

        matrixTMP = inverseMatrix.toArray2();
        perem = decoded.length;
        step = 0;
        List<int[]> decode = new ArrayList();
        messagePart = new int[0];
        while (perem >= num) {
            messagePart = Arrays.copyOfRange(decoded, step, (step + num));
            step += num;
            perem -= num;
            double[] C = multiplier(matrixTMP, messagePart);
            int[] intArray = new int[C.length];
            for (int i = 0; i < intArray.length; ++i) {
                intArray[i] = (int) Math.round(C[i]);
            }
            decode.add(intArray);
            int k = 0;
        }

        for (String str : result) {
            System.out.print(str + " ");
        }

        for (Map.Entry<Integer, Character> me : set) {
            result.add(me.getKey(), me.getValue().toString());  
        }
        ArrayList<String> decodedresult = new ArrayList<>();
        for (int[] is : decode) {
            for (int i : is) {
                System.out.print(i + " ");
                decodedresult.add(alphabet.get(i).toString());
            }
        }

        System.out.println("Проверка:");

        for (Map.Entry<Integer, Character> me : set) {
            decodedresult.add(me.getKey(), me.getValue().toString()); 
        }

        for (String str : decodedresult) {
            System.out.print(str);
        }
    }
}

